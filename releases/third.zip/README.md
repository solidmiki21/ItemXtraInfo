# Item Xtra Info

Item Xtra Info is a mod that calculates item bonus, chances, stats and all that stuff. It only shows
when you hover the move over the **TAB** menu items.

This mod is a spiritual successor to [The ItemStatsMod](https://thunderstore.io/package/ontrigger/ItemStatsMod/) made by ontrigger, I think he stopped developing it so i am taking over the idea.

---

Currently I'm still working on it but it should be ~~good~~ enough to play.

I know there are a lot of mistakes and inconsistency and for that i need help, you can report
errors in the github page (create a new issue, suggestions appreciated aswell ^.^!) aswell as look into the code (which is pretty bad tbh).

--- 

BEPIN AS WELL AS R2API ARE BOTH REQUIRED FOR THE MOD TO WORK.

Installation is just dropping the .dll file into the plugins folders bepin creates.

---

Find me on twitter: [@Solidmiki21](https://twitter.com/solidmiki21).  
And discord: @Solidmiki21#6992.

---


Kudos to my friend Alfonsohh for the new icon.
